




Created by caiiiycuk on 09.12.2019.



  

```

#ifndef JS_DOS_JS_DOS_DEBUG_HPP
#define JS_DOS_JS_DOS_DEBUG_HPP

bool DEBUG_JsDos_ParseCommand(char* str);

#endif //JS_DOS_JS_DOS_DEBUG_HPP


```




