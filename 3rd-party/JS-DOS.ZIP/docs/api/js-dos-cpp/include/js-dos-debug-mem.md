




Created by caiiiycuk on 09.12.2019.



  

```

#ifndef JS_DOS_JS_DOS_DEBUG_MEM_H
#define JS_DOS_JS_DOS_DEBUG_MEM_H

void MemAddSearchValue(Bit8u val);
void MemSearchExecute();
void MemSearchShowResult();

void WriteSnapshot();
void RestoreSnapshot();

#endif //JS_DOS_JS_DOS_DEBUG_MEM_H


```




